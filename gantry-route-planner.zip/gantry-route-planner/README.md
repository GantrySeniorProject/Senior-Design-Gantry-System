# Gantry Route Planner

A 3D gantry workspace in the browser. The hook leaves home empty, lifts a load at A and carries
it to B, passing over anything shorter than the room left under it (A* search, Manhattan distance,
no diagonals). Includes CAD import (STL, OBJ, STEP), stacking, keep-out zones, a person-detection
emergency stop, and a test panel.

## What's in this folder

| File | What it is |
| --- | --- |
| `index.html` | The whole app: page, styles, JavaScript, and the Python core embedded in a `<script type="text/python">` block run by Brython |
| `occt-import-js.wasm` | The STEP/IGES reader engine, loaded only when you import a STEP or IGES file |
| `python/gantry_core.py` | The same Python core as a plain module: A*, the height rule, load footprint, safety area check |
| `python/test_gantry_core.py` | 20 pytest tests: PDF tests, integrated jobs, safety checks |

## Run the app

Serve the folder over HTTP (opening the file directly works except for STEP import):

```
cd gantry-route-planner
python -m http.server 8000
```

Then open http://localhost:8000 in Chrome, Edge or Firefox.

It needs an internet connection the first time: three.js 0.147.0, Brython 3.13.2 and
occt-import-js 0.0.23 load from cdn.jsdelivr.net. To run fully offline, download those files
and point the `<script src>` lines in `index.html` at the local copies.

Your layout, imported CAD files and custom tests are saved in the browser (IndexedDB and
localStorage) for that browser only.

## Run the core tests

```
cd gantry-route-planner/python
pip install pytest
pytest -q
```

## Changing the logic

`python/gantry_core.py` and the Python block inside `index.html` are the same code. If you change
one, copy it into the other (everything above the `# ---- Hand the functions to the page ----` line
in `index.html`), then run the tests and reload the page.
