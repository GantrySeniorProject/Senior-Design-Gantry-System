"""Tests for the gantry core. Run with:  pytest -q   (from this folder)

The same cases run in the web page's Tests panel. Expected values were worked out by hand.
"""
from gantry_core import (HOME, one_safe_move, pick_and_place, people_in_area)


def heights(rects):
    """rects: (x, y, width, depth, height_cm) -> {cell: stack height}"""
    hm = {}
    for x, y, w, d, h in rects:
        for i in range(w):
            for j in range(d):
                hm[(x + i, y + j)] = max(hm.get((x + i, y + j), 0), h)
    return hm


def job(w, h, a, b, rects=(), keepout=(), clearance=120, load=30, footprint=((0, 0),), homed=True):
    return pick_and_place(w, h, heights(rects), set(keepout), clearance, load, homed, a, b, footprint)


# ---- From the PDF -------------------------------------------------------------

def test_pdf_test2_route_and_first_two_rounds():
    r = one_safe_move(3, 3, {(1, 0): ""}, True, HOME, (2, 0))
    assert r["route"] == [(0, 0), (0, 1), (1, 1), (2, 1), (2, 0)]
    r1, r2 = r["rounds"][0], r["rounds"][1]
    assert r1["expand"] == (0, 0) and r1["open"] == [((0, 1), 1, 3)]
    assert r2["expand"] == (0, 1) and r2["open"] == [((1, 1), 2, 2), ((0, 2), 2, 4)]


def test_pdf_errors_in_plan_order():
    assert one_safe_move(3, 3, {}, True, HOME, (3, 0))["error"] == "Error: target out of bounds."
    assert one_safe_move(3, 3, {(2, 2): ""}, True, HOME, (2, 2))["error"] == "Error: target blocked."
    assert one_safe_move(3, 3, {}, False, HOME, (2, 2))["error"] == "Error: not homed."
    assert one_safe_move(3, 3, {(1, 0): "", (0, 1): ""}, True, HOME, (2, 2))["error"] == "Error: no route found."


# ---- Integrated: full job through the height rule ----------------------------

STRAIGHT_5 = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0)]


def test_loaded_hook_passes_over_low_pallet():
    leg1, leg2 = job(5, 1, (0, 0), (4, 0), [(2, 0, 1, 1, 40)])
    assert leg1["route"] == [(0, 0)] and leg2["route"] == STRAIGHT_5


def test_equal_height_blocks_strict_rule():
    leg1, leg2 = job(5, 1, (0, 0), (4, 0), [(2, 0, 1, 1, 90)])
    assert leg2["error"] == "Error: no route found."


def test_half_cm_lower_passes():
    _, leg2 = job(5, 1, (0, 0), (4, 0), [(2, 0, 1, 1, 89.5)])
    assert leg2["route"] == STRAIGHT_5


def test_empty_passes_loaded_detours():
    leg1, leg2 = job(5, 3, (4, 0), (0, 0), [(2, 0, 1, 2, 100)])
    assert leg1["route"] == STRAIGHT_5
    assert len(leg2["route"]) - 1 == 8
    assert (2, 0) not in leg2["route"] and (2, 1) not in leg2["route"]


def test_tall_column_blocks_both():
    legs = job(3, 1, (2, 0), (0, 0), [(1, 0, 1, 1, 200)])
    assert len(legs) == 1 and legs[0]["error"] == "Error: no route found."


def test_keepout_blocks_at_floor_level():
    leg1, leg2 = job(3, 3, (2, 0), (2, 2), keepout=[(1, 0)])
    assert leg1["route"] == [(0, 0), (0, 1), (1, 1), (2, 1), (2, 0)]
    assert leg2["route"] == [(2, 0), (2, 1), (2, 2)]


def test_wide_load_cannot_fit_one_cell_gap():
    _, leg2 = job(5, 3, (0, 0), (4, 0), [(2, 0, 1, 1, 200), (2, 2, 1, 1, 200)], footprint=((0, 0), (0, 1)))
    assert leg2["error"] == "Error: no route found."


def test_one_cell_load_fits_gap():
    leg1, leg2 = job(5, 3, (0, 1), (4, 1), [(2, 0, 1, 1, 200), (2, 2, 1, 1, 200)])
    assert leg1["route"] == [(0, 0), (0, 1)]
    assert leg2["route"] == [(0, 1), (1, 1), (2, 1), (3, 1), (4, 1)]


def test_drop_on_too_tall_stack():
    _, leg2 = job(4, 1, (0, 0), (3, 0), [(3, 0, 1, 1, 95)])
    assert leg2["error"] == "Error: target blocked."


def test_set_down_on_low_pallet():
    _, leg2 = job(4, 1, (0, 0), (3, 0), [(3, 0, 1, 1, 40)])
    assert leg2["route"] == [(0, 0), (1, 0), (2, 0), (3, 0)]


def test_not_homed_stops_before_search():
    legs = job(4, 1, (0, 0), (3, 0), homed=False)
    assert len(legs) == 1 and legs[0]["error"] == "Error: not homed." and legs[0]["rounds"] == []


def test_wide_load_outside_grid():
    _, leg2 = job(4, 1, (0, 0), (3, 0), footprint=((0, 0), (1, 0)))
    assert leg2["error"] == "Error: target out of bounds."


# ---- Safety: area scanner (200 x 150 cm floor, 20 cm body radius) -------------

def stop(*people):
    return bool(people_in_area(list(people), 200, 150))


def test_outside_no_stop():
    assert not stop((260, 75))


def test_inside_stop():
    assert stop((100, 75))


def test_reaching_over_edge_stop():
    assert stop((-15, 75))


def test_just_clear_no_stop():
    assert not stop((-21, 75))


def test_corner_true_distance_no_stop():
    assert not stop((-15, -15))  # about 21.2 cm from the corner


def test_one_of_two_inside_stop():
    assert stop((260, 75), (50, 140))
