# Gantry pathfinder: A* search on the workspace grid, following the team's plan.
# Coordinates: x to the right, y away from the operator. Home is (0, 0).
# Moves: right, up, left, down only (no diagonals). Every move costs 1,
# so h = |dx| + |dy| never overestimates and the route found is a shortest one.
#
# 3D change: a cell is blocked only when whatever stands on it is too tall to pass over.
# The hook may pass over a cell when  clearance - carried height > stack height.
# Keep-out zones are always blocked. While the load is carried, every cell under
# the load's footprint has to pass, not just the cell under the hook.

HOME = (0, 0)
NEIGHBORS = [((1, 0), "right"), ((0, 1), "up"), ((-1, 0), "left"), ((0, -1), "down")]
INF = float("inf")


def h_cost(cell, target):
    return abs(cell[0] - target[0]) + abs(cell[1] - target[1])


def inside(cell, w, h):
    return 0 <= cell[0] < w and 0 <= cell[1] < h


def fmt(cell):
    return "(" + str(cell[0]) + ", " + str(cell[1]) + ")"


def cm(v):
    v = round(v, 1)
    return str(int(v)) if v == int(v) else str(v)


def blocked_cells(heights, keepout, clearance, carried):
    """The one rule: a cell can be passed over when clearance - carried > stack height.
    Returns {cell: reason} for every cell that fails."""
    room = clearance - carried
    blocked = {}
    for cell in keepout:
        blocked[cell] = "keep-out zone"
    for cell, stack in heights.items():
        if cell not in blocked and not (room > stack):
            blocked[cell] = "stack " + cm(stack) + " cm, room " + cm(room) + " cm"
    return blocked


def footprint_problem(w, h, blocked, cell, footprint):
    """None if every footprint cell is inside the grid and passable, else (kind, cell, reason)."""
    for dx, dy in footprint:
        c = (cell[0] + dx, cell[1] + dy)
        if not inside(c, w, h):
            return ("outside", c, "")
        if c in blocked:
            return ("blocked", c, blocked[c])
    return None


def find_route(w, h, blocked, start, target, footprint=((0, 0),)):
    """Plan lines 8-18. Returns (route, rounds); route is [] when there is none."""
    wide = len(footprint) > 1
    g = {start: 0}
    parent = {}
    open_order = {start: 0}  # cell -> its place in the order cells were added to open
    added = 1
    closed = set()
    rounds = []

    def rank(n):
        hn = h_cost(n, target)
        return (g[n] + hn, hn, open_order[n])

    def open_list(skip=None):
        cells = sorted((n for n in open_order if n != skip), key=rank)
        return [(n, g[n], h_cost(n, target)) for n in cells]

    while open_order:
        # Line 10: lowest f; ties go to lower h, then to the cell added to open first.
        c = min(open_order, key=rank)
        hc = h_cost(c, target)

        if c == target:  # Line 11: build the route by following parents back
            rounds.append({"expand": c, "g": g[c], "h": hc, "done": True,
                           "notes": ["this is the target: build the route"],
                           "open": open_list(skip=c)})
            route = [c]
            while route[-1] in parent:
                route.append(parent[route[-1]])
            route.reverse()
            return route, rounds

        del open_order[c]  # Line 12: move c from open to closed
        closed.add(c)
        notes = []
        for (dx, dy), name in NEIGHBORS:  # Line 13
            n = (c[0] + dx, c[1] + dy)
            problem = footprint_problem(w, h, blocked, n, footprint)
            if problem and problem[0] == "outside":
                notes.append(name + (" would put the load outside the grid" if wide else " is outside the grid"))
                continue
            if problem:
                why = problem[2]
                if wide or why:
                    where = fmt(problem[1]) + " " if wide else ""
                    notes.append(name + " " + fmt(n) + " is blocked: " + where + why)
                else:
                    notes.append(name + " " + fmt(n) + " is blocked")
                continue
            new_g = g[c] + 1
            if new_g >= g.get(n, INF):  # Line 14
                where = "closed" if n in closed else "already in open"
                notes.append(name + " " + fmt(n) + " is " + where + ", not shorter: skipped")
                continue
            # Line 15
            was_open = n in open_order
            g[n] = new_g
            parent[n] = c
            if n in closed:
                closed.discard(n)
                open_order[n] = added
                added += 1
                notes.append(name + " " + fmt(n) + " reopened with g " + str(new_g))
            elif not was_open:
                open_order[n] = added
                added += 1
                notes.append(name + " " + fmt(n) + " added to open")
            else:
                notes.append(name + " " + fmt(n) + " updated to g " + str(new_g) + ", keeps its place")
        rounds.append({"expand": c, "g": g[c], "h": hc, "done": False,
                       "notes": notes, "open": open_list()})

    return [], rounds


def one_safe_move(w, h, blocked, homed, start, target, footprint=((0, 0),)):
    """Plan lines 3-19 for one move. Checks run in the plan's order."""
    problem = footprint_problem(w, h, blocked, target, footprint)
    if problem and problem[0] == "outside":
        return {"error": "Error: target out of bounds.", "route": [], "rounds": []}
    if problem:
        return {"error": "Error: target blocked.", "why": fmt(problem[1]) + " " + problem[2],
                "route": [], "rounds": []}
    if not homed:
        return {"error": "Error: not homed.", "route": [], "rounds": []}
    route, rounds = find_route(w, h, blocked, start, target, footprint)
    if not route:
        return {"error": "Error: no route found.", "route": [], "rounds": rounds}
    return {"error": None, "route": route, "rounds": rounds}


def printout(result):
    lines = []
    for i, r in enumerate(result["rounds"], 1):
        lines.append("Round " + str(i) + ": expand " + fmt(r["expand"]) + "  g " + str(r["g"]) +
                     ", h " + str(r["h"]) + ", f " + str(r["g"] + r["h"]))
        for note in r["notes"]:
            lines.append("    " + note)
        if r["open"]:
            lines.append("    open: " + "; ".join(fmt(n) + ": " + str(g) + ", " + str(h) + ", " + str(g + h)
                                                for n, g, h in r["open"]))
        else:
            lines.append("    open: (empty)")
    if result["error"]:
        lines.append(result["error"] + (" " + result["why"] if result.get("why") else ""))
    else:
        lines.append("Route: " + " -> ".join(fmt(c) for c in result["route"]))
    return "\n".join(lines)


def pick_and_place(w, h, heights, keepout, clearance, load_height, homed, a, b, footprint):
    """Leg 1: home to A with the hook empty. Leg 2: A to B carrying the load."""
    leg1 = one_safe_move(w, h, blocked_cells(heights, keepout, clearance, 0), homed, HOME, a)
    if leg1["error"]:
        return [leg1]
    leg2 = one_safe_move(w, h, blocked_cells(heights, keepout, clearance, load_height), homed, a, b, footprint)
    return [leg1, leg2]


# ---- Safety: area scanner and emergency stop (Controller) ----
# A person seen from above is a circle. If any part of it reaches over the
# workspace floor, the controller latches an emergency stop: the gantry halts
# where it is and stays stopped until the area is clear and someone resets it.
PERSON_RADIUS = 20  # cm


def people_in_area(people, width, depth):
    """Return the indexes of people whose outline reaches inside the workspace."""
    inside = []
    for i, (x, y) in enumerate(people):
        nearest_x = min(max(x, 0), width)
        nearest_y = min(max(y, 0), depth)
        if (x - nearest_x) ** 2 + (y - nearest_y) ** 2 < PERSON_RADIUS ** 2:
            inside.append(i)
    return inside


def can_reset(people, width, depth):
    """The stop may only be reset once nobody is in the area."""
    return not people_in_area(people, width, depth)


# ---- Bridge to the page: plain text in, JSON text out ----

def parse_cells(text):
    cells = set()
    for pair in text.split(";"):
        if pair:
            x, y = pair.split(",")
            cells.add((int(x), int(y)))
    return cells


def parse_heights(text):
    heights = {}
    for item in text.split(";"):
        if item:
            x, y, z = item.split(",")
            heights[(int(x), int(y))] = float(z)
    return heights


def to_json(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        return '"' + v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'
    if isinstance(v, dict):
        return "{" + ",".join(to_json(k) + ":" + to_json(x) for k, x in v.items()) + "}"
    return "[" + ",".join(to_json(x) for x in v) + "]"


def packed(result):
    return {
        "error": result["error"],
        "route": [list(c) for c in result["route"]],
        "rounds": [{"expand": list(r["expand"]), "g": r["g"], "h": r["h"],
                    "open": [[n[0], n[1], g, h] for n, g, h in r["open"]]}
                   for r in result["rounds"]],
        "printout": printout(result),
        "why": result.get("why"),
    }


def js_job(w, h, heights_text, keepout_text, clearance, load_height, homed, ax, ay, bx, by, footprint_text):
    footprint = tuple(sorted(parse_cells(footprint_text))) or ((0, 0),)
    legs = pick_and_place(int(w), int(h), parse_heights(heights_text), parse_cells(keepout_text),
                          float(clearance), float(load_height), bool(homed),
                          (int(ax), int(ay)), (int(bx), int(by)), footprint)
    return to_json([packed(leg) for leg in legs])


def js_move(w, h, blocked_text, homed, tx, ty):
    # The plan's tests: blocked cells are simply blocked, the hook starts at home.
    blocked = {cell: "" for cell in parse_cells(blocked_text)}
    return to_json(packed(one_safe_move(int(w), int(h), blocked, bool(homed), HOME, (int(tx), int(ty)))))


def js_people(people_text, width, depth):
    people = []
    for item in people_text.split(";"):
        if item:
            x, y = item.split(",")
            people.append((float(x), float(y)))
    return to_json(people_in_area(people, float(width), float(depth)))
